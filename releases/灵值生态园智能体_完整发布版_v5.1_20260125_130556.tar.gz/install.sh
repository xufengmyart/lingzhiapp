#!/bin/bash
# 灵值生态园智能体 - 快速安装脚本

echo "========================================"
echo "  灵值生态园智能体 - 快速安装"
echo "========================================"
echo ""

# 检查 Python 版本
echo "[1/5] 检查 Python 版本..."
python_version=$(python3 --version 2>&1 | awk '{print $2}')
echo "当前 Python 版本：$python_version"

# 安装依赖
echo ""
echo "[2/5] 安装依赖..."
pip3 install -r requirements.txt

# 初始化数据库
echo ""
echo "[3/5] 初始化数据库..."
cd src/auth
python3 init_data.py
python3 init_ecosystem.py
python3 init_project.py
cd ../..

echo ""
echo "[4/5] 添加收款码文件..."
echo "请将以下文件添加到 assets/ 目录："
echo "  - 个人微信收款码.jpg"
echo "  - 个人支付宝收款码.jpg"
read -p "按回车键继续..."

# 启动服务
echo ""
echo "[5/5] 启动服务..."
echo "服务地址：http://localhost:8000"
echo "API文档：http://localhost:8000/docs"
echo ""
read -p "是否立即启动服务？(y/n) " -n 1 -r
echo ""
if [[ $REPLY =~ ^[Yy]$ ]]; then
    python3 -m uvicorn src.main:app --host 0.0.0.0 --port 8000 --reload
fi

echo ""
echo "========================================"
echo "  安装完成！"
echo "========================================"
