"""知识库搜索工具"""
from langchain.tools import tool
from langchain.tools import ToolRuntime
from coze_coding_dev_sdk import KnowledgeClient


@tool
def search_knowledge(query: str, runtime: ToolRuntime) -> str:
    """搜索知识库中的西安文化、品牌转译相关信息
    
    Args:
        query: 搜索关键词，例如"西安文化"、"唐风"、"秦岭"等
    
    Returns:
        返回知识库中相关的内容摘要
    """
    ctx = runtime.context
    client = KnowledgeClient(ctx=ctx)
    
    try:
        response = client.search(
            query=query,
            top_k=5,
            min_score=0.7
        )
        
        if response.code == 0 and response.chunks:
            results = []
            for i, chunk in enumerate(response.chunks, 1):
                results.append(f"[相关度: {chunk.score:.2f}] {chunk.content}")
            return "\n\n".join(results)
        else:
            return f"未在知识库中找到关于'{query}'的相关信息。请尝试更具体的关键词。"
    except Exception as e:
        return f"知识库搜索出错: {str(e)}"
