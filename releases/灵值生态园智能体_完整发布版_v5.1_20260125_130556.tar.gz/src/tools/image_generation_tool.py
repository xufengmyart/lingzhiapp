"""文生图工具"""
from langchain.tools import tool
from langchain.tools import ToolRuntime
from coze_coding_dev_sdk import ImageGenerationClient
from coze_coding_utils.runtime_ctx.context import new_context


@tool
def generate_image(prompt: str, runtime: ToolRuntime) -> str:
    """根据描述生成图片，用于创建品牌视觉创意、概念图等
    
    Args:
        prompt: 图片描述，例如"一个充满东方韵味的茶文化品牌logo设计，简洁现代风格"
    
    Returns:
        返回生成的图片URL
    """
    ctx = new_context(method="generate")
    client = ImageGenerationClient(ctx=ctx)
    
    try:
        response = client.generate(
            prompt=prompt,
            size="2K",
            watermark=False
        )
        
        if response.success and response.image_urls:
            return f"✅ 图片生成成功！\n图片URL: {response.image_urls[0]}\n\n您可以点击链接查看或下载图片。"
        else:
            error_msg = response.error_messages[0] if response.error_messages else "未知错误"
            return f"图片生成失败: {error_msg}"
    except Exception as e:
        return f"图片生成出错: {str(e)}"
