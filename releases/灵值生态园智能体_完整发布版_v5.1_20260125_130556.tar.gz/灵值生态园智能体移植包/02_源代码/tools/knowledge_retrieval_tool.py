"""
知识库检索工具
版本：v5.0
"""

from langchain.tools import tool
from langchain.tools import ToolRuntime
from coze_coding_dev_sdk import KnowledgeBaseClient


@tool
def retrieve_knowledge(query: str, runtime: ToolRuntime) -> str:
    """检索知识库中的文档
    
    Args:
        query: 检索关键词
    
    Returns:
        返回检索到的文档内容
    """
    ctx = runtime.context
    client = KnowledgeBaseClient(ctx=ctx)
    
    try:
        response = client.search(
            query=query,
            top_k=5,
            threshold=0.7
        )
        
        if response.code == 0 and response.documents:
            results = "\n\n".join([f"文档{i+1}:\n{doc.content}" for i, doc in enumerate(response.documents)])
            return f"知识库检索结果：\n{results}"
        else:
            return f"知识库检索失败：{response.message}"
    except Exception as e:
        return f"知识库检索出错: {str(e)}"
