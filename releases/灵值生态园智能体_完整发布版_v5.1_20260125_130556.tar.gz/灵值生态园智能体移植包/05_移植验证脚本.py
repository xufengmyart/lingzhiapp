"""
灵值生态园智能体移植验证脚本
版本：v5.0
更新日期：2026年1月23日
"""

import os
import json
import sys
from pathlib import Path


class MigrationPackageValidator:
    """移植包验证器"""
    
    def __init__(self, root_dir="."):
        """初始化验证器
        
        Args:
            root_dir: 移植包根目录
        """
        self.root_dir = Path(root_dir)
        self.check_results = []
    
    def check_file_exists(self, file_path, description):
        """检查文件是否存在
        
        Args:
            file_path: 文件路径
            description: 文件描述
        
        Returns:
            bool: 文件是否存在
        """
        full_path = self.root_dir / file_path
        exists = full_path.exists()
        
        status = "✅" if exists else "❌"
        result = f"{status} {description}: {file_path}"
        self.check_results.append(result)
        
        if not exists:
            print(result)
        
        return exists
    
    def check_json_valid(self, file_path, description):
        """检查JSON文件是否有效
        
        Args:
            file_path: JSON文件路径
            description: 文件描述
        
        Returns:
            bool: JSON文件是否有效
        """
        full_path = self.root_dir / file_path
        
        if not full_path.exists():
            self.check_results.append(f"❌ {description}: 文件不存在")
            return False
        
        try:
            with open(full_path, 'r', encoding='utf-8') as f:
                json.load(f)
            
            self.check_results.append(f"✅ {description}: {file_path}")
            return True
        except Exception as e:
            self.check_results.append(f"❌ {description}: JSON解析失败 - {str(e)}")
            return False
    
    def check_config_keys(self, file_path, required_keys, description):
        """检查配置文件是否包含必需的键
        
        Args:
            file_path: 配置文件路径
            required_keys: 必需的键列表
            description: 文件描述
        
        Returns:
            bool: 配置文件是否包含所有必需的键
        """
        full_path = self.root_dir / file_path
        
        if not full_path.exists():
            self.check_results.append(f"❌ {description}: 文件不存在")
            return False
        
        try:
            with open(full_path, 'r', encoding='utf-8') as f:
                data = json.load(f)
            
            missing_keys = [key for key in required_keys if key not in data]
            
            if missing_keys:
                self.check_results.append(f"❌ {description}: 缺少必需的键 - {', '.join(missing_keys)}")
                return False
            else:
                self.check_results.append(f"✅ {description}: {file_path}")
                return True
        except Exception as e:
            self.check_results.append(f"❌ {description}: 配置解析失败 - {str(e)}")
            return False
    
    def run_all_checks(self):
        """运行所有检查"""
        print("=" * 60)
        print("开始移植包验证...")
        print("=" * 60)
        print()
        
        # 检查核心文件
        print("1. 检查核心文件...")
        checks = [
            ("README.md", "移植包说明"),
            ("00_移植指南.md", "移植指南"),
            ("04_部署检查清单.md", "部署检查清单"),
            ("05_移植验证脚本.py", "移植验证脚本"),
        ]
        
        for file_path, description in checks:
            self.check_file_exists(file_path, description)
        
        print()
        
        # 检查智能体配置
        print("2. 检查智能体配置...")
        checks = [
            ("01_智能体配置/基本信息.json", "基本信息"),
            ("01_智能体配置/系统提示词.md", "系统提示词"),
            ("01_智能体配置/模型配置.json", "模型配置"),
            ("01_智能体配置/工具配置.md", "工具配置"),
        ]
        
        for file_path, description in checks:
            self.check_file_exists(file_path, description)
        
        print()
        
        # 检查源代码
        print("3. 检查源代码...")
        checks = [
            ("02_源代码/agent.py", "智能体核心代码"),
            ("02_源代码/tools/knowledge_retrieval_tool.py", "知识库检索工具"),
            ("02_源代码/tools/image_generation_tool.py", "图像生成工具"),
        ]
        
        for file_path, description in checks:
            self.check_file_exists(file_path, description)
        
        print()
        
        # 检查知识库文档
        print("4. 检查知识库文档...")
        checks = [
            ("03_知识库文档/00_知识库文档索引.md", "知识库文档索引"),
        ]
        
        for file_path, description in checks:
            self.check_file_exists(file_path, description)
        
        print()
        
        # 验证JSON文件
        print("5. 验证JSON文件...")
        checks = [
            ("01_智能体配置/基本信息.json", "基本信息"),
            ("01_智能体配置/模型配置.json", "模型配置"),
        ]
        
        for file_path, description in checks:
            self.check_json_valid(file_path, description)
        
        print()
        
        # 验证配置文件
        print("6. 验证配置文件...")
        checks = [
            ("01_智能体配置/基本信息.json", ["name", "description", "tags", "category"], "基本信息"),
            ("01_智能体配置/模型配置.json", ["config", "sp", "tools"], "模型配置"),
        ]
        
        for file_path, required_keys, description in checks:
            self.check_config_keys(file_path, required_keys, description)
        
        print()
        print("=" * 60)
        
        # 统计结果
        total_checks = len(self.check_results)
        passed_checks = len([r for r in self.check_results if r.startswith("✅")])
        failed_checks = len([r for r in self.check_results if r.startswith("❌")])
        
        print(f"验证完成！")
        print(f"总检查项：{total_checks}")
        print(f"通过：{passed_checks}")
        print(f"失败：{failed_checks}")
        print("=" * 60)
        
        if failed_checks == 0:
            print("\n✅ 移植包验证通过！")
            print("可以开始部署了！")
            return True
        else:
            print(f"\n❌ 移植包验证失败！")
            print(f"有 {failed_checks} 项检查未通过，请修复后重试。")
            return False


def main():
    """主函数"""
    # 获取移植包根目录
    if len(sys.argv) > 1:
        root_dir = sys.argv[1]
    else:
        root_dir = "."
    
    # 创建验证器并运行检查
    validator = MigrationPackageValidator(root_dir)
    success = validator.run_all_checks()
    
    # 退出码
    sys.exit(0 if success else 1)


if __name__ == "__main__":
    main()
