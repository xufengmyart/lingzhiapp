"""
图像生成工具
版本：v5.0
"""

from langchain.tools import tool
from langchain.tools import ToolRuntime
from coze_coding_dev_sdk import ImageGenerationClient


@tool
def generate_image(prompt: str, style: str = "realistic", runtime: ToolRuntime) -> str:
    """生成品牌视觉创意、空间设计方案等图像
    
    Args:
        prompt: 图像生成提示词，例如"唐风茶馆设计，优雅大气"
        style: 图像风格，默认为"realistic"（写实风格）
    
    Returns:
        返回生成图像的URL
    """
    ctx = runtime.context
    client = ImageGenerationClient(ctx=ctx)
    
    try:
        response = client.generate(
            prompt=prompt,
            style=style,
            image_size="1024x1024",
            num_images=1
        )
        
        if response.code == 0 and response.images:
            image_urls = "\n".join([img.url for img in response.images])
            return f"图像生成成功！\n{image_urls}"
        else:
            return f"图像生成失败：{response.message}"
    except Exception as e:
        return f"图像生成出错: {str(e)}"
