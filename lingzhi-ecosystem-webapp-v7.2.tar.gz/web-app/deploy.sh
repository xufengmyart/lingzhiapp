#!/bin/bash

echo "=========================================="
echo "灵值生态园 APP 部署脚本"
echo "=========================================="

# 颜色定义
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m' # No Color

# 检查Node.js
echo -e "${YELLOW}[1/6] 检查环境...${NC}"
if ! command -v node &> /dev/null; then
    echo -e "${RED}错误: Node.js未安装${NC}"
    exit 1
fi
echo -e "${GREEN}✓ Node.js版本: $(node --version)${NC}"

if ! command -v npm &> /dev/null; then
    echo -e "${RED}错误: npm未安装${NC}"
    exit 1
fi
echo -e "${GREEN}✓ npm版本: $(npm --version)${NC}"

# 清理旧的构建
echo -e "${YELLOW}[2/6] 清理旧构建...${NC}"
rm -rf dist
rm -rf node_modules
echo -e "${GREEN}✓ 清理完成${NC}"

# 安装依赖
echo -e "${YELLOW}[3/6] 安装依赖...${NC}"
npm install
if [ $? -ne 0 ]; then
    echo -e "${RED}错误: 依赖安装失败${NC}"
    exit 1
fi
echo -e "${GREEN}✓ 依赖安装完成${NC}"

# 构建项目
echo -e "${YELLOW}[4/6] 构建项目...${NC}"
npm run build
if [ $? -ne 0 ]; then
    echo -e "${RED}错误: 构建失败${NC}"
    exit 1
fi
echo -e "${GREEN}✓ 构建完成${NC}"

# 验证构建
echo -e "${YELLOW}[5/6] 验证构建...${NC}"
if [ ! -d "dist" ]; then
    echo -e "${RED}错误: dist目录不存在${NC}"
    exit 1
fi
if [ ! -f "dist/index.html" ]; then
    echo -e "${RED}错误: index.html不存在${NC}"
    exit 1
fi
echo -e "${GREEN}✓ 构建验证通过${NC}"

# 显示构建信息
echo -e "${YELLOW}[6/6] 构建信息...${NC}"
echo "构建产物:"
ls -lh dist/
echo ""
echo "构建产物大小:"
du -sh dist/
echo ""

echo "=========================================="
echo -e "${GREEN}部署完成！${NC}"
echo "=========================================="
echo ""
echo "接下来的步骤:"
echo "1. 将 dist/ 目录上传到服务器"
echo "2. 配置Nginx或Docker"
echo "3. 启动服务"
echo ""
echo "更多详情请参阅 DEPLOYMENT.md"
