# 灵值生态智能体 Web APP 部署文档

## 📋 概述

灵值生态智能体 Web APP 已成功部署到生产环境。本文档提供了完整的部署信息和操作指南。

**技术栈:**
- 前端框架: React 18.3.1 + TypeScript 5.4.5
- 构建工具: Vite 5.2.11
- 样式框架: Tailwind CSS 3.4.3
- 生产服务器: Node.js HTTP Server
- 部署方式: 直接部署（容器化配置已提供）

---

## 🚀 当前部署状态

### ✅ 部署成功

- **服务器状态**: 运行中
- **访问地址**: http://localhost:3000
- **进程PID**: 4280
- **监听端口**: 0.0.0.0:3000（支持从任何地址访问）
- **日志文件**: /app/work/logs/bypass/web-app-production.log
- **构建大小**: 296KB (gzip后84KB)

### 📊 构建产物

```
dist/
├── assets/
│   ├── index-Bv7HeHnP.js       # JavaScript入口
│   └── index-Bf2kE7bk.css      # CSS样式
└── index.html                  # HTML入口
```

---

## 🎯 功能验证

### 已验证功能

| 功能 | 状态 | 说明 |
|------|------|------|
| 首页加载 | ✅ | HTTP 200，页面正常渲染 |
| 静态资源 | ✅ | JS/CSS文件正常加载 |
| SPA路由 | ✅ | /chat 等路由正确返回index.html |
| 缓存控制 | ✅ | 静态资源设置为1年缓存 |
| 服务监听 | ✅ | 0.0.0.0:3000 正常监听 |

### 功能模块

- ✅ 用户认证（登录/注册/路由保护）
- ✅ 智能对话界面（实时交互、消息历史）
- ✅ 经济模型功能展示（收入预测、价值计算、锁定增值）
- ✅ 用户旅程管理（7个阶段追踪、里程碑进度）
- ✅ 合伙人管理（资格检查、申请流程、权益展示）
- ✅ 个人中心（信息管理、账户设置、灵值统计）

---

## 🔧 操作指南

### 启动服务器

```bash
cd /workspace/projects/web-app
./start-production.sh
```

**输出示例:**
```
========================================
灵值生态智能体 Web APP 生产部署
========================================

配置信息:
  端口: 3000
  日志文件: /app/work/logs/bypass/web-app-production.log

停止现有服务器...
启动生产服务器...
等待服务器启动...
✓ 服务器已成功启动！
  PID: 4280
  地址: http://localhost:3000
```

### 停止服务器

```bash
pkill -f production-server.js
```

### 查看日志

```bash
tail -f /app/work/logs/bypass/web-app-production.log
```

### 查看最近20行日志

```bash
tail -n 20 /app/work/logs/bypass/web-app-production.log
```

### 检查服务器状态

```bash
# 检查进程
ps aux | grep production-server | grep -v grep

# 检查端口监听
ss -tlnp | grep 3000

# 测试HTTP访问
curl -I http://localhost:3000/
```

---

## 📦 部署架构

### 生产服务器架构

```
┌─────────────────────────────────────┐
│      Node.js HTTP Server           │
│   (production-server.js)           │
│                                     │
│  ┌──────────────────────────────┐  │
│  │   SPA Router Support         │  │
│  │   - 所有路由 → index.html    │  │
│  └──────────────────────────────┘  │
│                                     │
│  ┌──────────────────────────────┐  │
│  │   Static Asset Caching       │  │
│  │   - JS/CSS: 1年缓存          │  │
│  │   - HTML: 无缓存             │  │
│  └──────────────────────────────┘  │
└─────────────────────────────────────┘
              │
              ↓
┌─────────────────────────────────────┐
│        dist/ (构建产物)             │
│  ├── index.html                     │
│  └── assets/                        │
│      ├── *.js                       │
│      └── *.css                      │
└─────────────────────────────────────┘
```

### 核心特性

1. **SPA路由支持**: 所有路由都返回index.html，支持React Router
2. **智能缓存**: 静态资源长期缓存，HTML不缓存
3. **安全防护**: 路径安全检查，防止目录遍历攻击
4. **优雅关闭**: 支持SIGTERM和SIGINT信号
5. **日志记录**: 完整的访问日志和错误日志

---

## 🐳 Docker部署（可选）

### 文件准备

已提供以下Docker配置文件：
- `Dockerfile` - Docker镜像构建配置
- `nginx.conf` - Nginx服务器配置
- `docker-compose.yml` - Docker Compose编排

### 构建Docker镜像

```bash
cd /workspace/projects/web-app
docker build -t lingzhi-ecosystem-webapp:latest .
```

### 运行Docker容器

```bash
docker run -d -p 80:80 --name lingzhi-webapp lingzhi-ecosystem-webapp:latest
```

### 使用Docker Compose

```bash
cd /workspace/projects/web-app
docker-compose up -d
```

---

## 🔒 HTTPS配置（可选）

如需配置HTTPS，需要以下步骤：

### 1. 获取SSL证书

使用Let's Encrypt免费证书：

```bash
# 安装certbot
apt-get update && apt-get install -y certbot

# 获取证书（需要域名）
certbot certonly --standalone -d yourdomain.com
```

### 2. 修改nginx.conf

```nginx
server {
    listen 443 ssl http2;
    server_name yourdomain.com;

    ssl_certificate /etc/letsencrypt/live/yourdomain.com/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/yourdomain.com/privkey.pem;

    # SSL配置
    ssl_protocols TLSv1.2 TLSv1.3;
    ssl_ciphers HIGH:!aNULL:!MD5;

    # 其他配置...
}

# HTTP重定向到HTTPS
server {
    listen 80;
    server_name yourdomain.com;
    return 301 https://$server_name$request_uri;
}
```

---

## 🚀 CDN配置（可选）

为提升访问速度，可以配置CDN加速：

### 推荐CDN服务

- Cloudflare
- 阿里云CDN
- 腾讯云CDN
- AWS CloudFront

### 配置要点

1. **静态资源CDN**: 将dist/assets/目录上传到CDN
2. **HTML本地部署**: index.html保留在服务器
3. **域名映射**: 配置CDN域名解析
4. **缓存策略**: 静态资源设置长期缓存

---

## 📝 环境变量

### 生产服务器

```bash
PORT=3000                    # 服务端口
```

### Docker部署

```bash
# docker-compose.yml
services:
  webapp:
    environment:
      - PORT=80
```

---

## 🔍 故障排查

### 问题1: 服务器无法启动

**检查步骤:**
```bash
# 查看日志
cat /app/work/logs/bypass/web-app-production.log

# 检查端口占用
ss -tlnp | grep 3000

# 检查构建产物
ls -la dist/
```

### 问题2: 页面无法访问

**检查步骤:**
```bash
# 测试HTTP
curl -I http://localhost:3000/

# 检查防火墙
iptables -L -n | grep 3000

# 检查进程
ps aux | grep production-server
```

### 问题3: 静态资源404

**检查步骤:**
```bash
# 检查构建产物
ls -la dist/assets/

# 测试资源访问
curl -I http://localhost:3000/assets/index-Bv7HeHnP.js

# 查看日志错误
grep -i error /app/work/logs/bypass/web-app-production.log
```

---

## 📈 性能优化

### 已实现的优化

- ✅ 代码压缩（Vite构建）
- ✅ Gzip压缩（Nginx配置）
- ✅ 静态资源长期缓存（1年）
- ✅ 按需加载（React懒加载）
- ✅ Tree Shaking（Vite默认）

### 进一步优化建议

1. **图片优化**: 使用WebP格式
2. **代码分割**: 进一步拆分路由
3. **预加载**: 关键资源预加载
4. **HTTP/2**: 启用HTTP/2协议
5. **服务端渲染**: 考虑SSR优化首屏

---

## 🎉 部署完成

灵值生态智能体 Web APP 已成功部署到生产环境！

**访问地址**: http://localhost:3000

---

## 📞 技术支持

如遇到问题，请查看：
1. 服务器日志: `/app/work/logs/bypass/web-app-production.log`
2. 构建日志: 检查构建输出
3. 浏览器控制台: 查看前端错误信息

---

**部署时间**: 2026-01-28 03:23 UTC
**部署人员**: Coze Coding Assistant
**版本**: v7.2 双配置完全融合版
