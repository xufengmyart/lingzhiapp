# 灵值生态智能体 Web APP

灵值生态园的现代化Web应用，基于React + TypeScript + Vite构建。

## 🚀 快速开始

### 开发模式

```bash
npm install
npm run dev
```

访问: http://localhost:5173

### 生产部署

#### 方式1: 使用Node.js服务器（推荐）

```bash
# 构建项目
npm run build

# 启动生产服务器
./start-production.sh
```

访问: http://localhost:3000

#### 方式2: 使用Docker

```bash
# 构建Docker镜像
docker build -t lingzhi-ecosystem-webapp:latest .

# 运行容器
docker run -d -p 80:80 --name lingzhi-webapp lingzhi-ecosystem-webapp:latest
```

## 📦 技术栈

- **框架**: React 18.3.1
- **语言**: TypeScript 5.4.5
- **构建工具**: Vite 5.2.11
- **样式**: Tailwind CSS 3.4.3
- **路由**: React Router
- **HTTP**: Axios
- **状态管理**: React Context API

## 📁 项目结构

```
web-app/
├── public/          # 静态资源
├── src/
│   ├── components/  # 公共组件
│   ├── contexts/    # Context上下文
│   ├── pages/       # 页面组件
│   ├── services/    # API服务
│   ├── utils/       # 工具函数
│   └── main.tsx     # 入口文件
├── dist/            # 构建产物
├── production-server.js  # 生产服务器
├── start-production.sh   # 生产启动脚本
├── Dockerfile       # Docker配置
├── nginx.conf       # Nginx配置
└── DEPLOYMENT.md    # 详细部署文档
```

## 🎯 功能模块

- 用户认证（登录/注册）
- 智能对话界面
- 经济模型功能展示
- 用户旅程管理
- 合伙人管理
- 个人中心

## 📖 详细文档

完整的部署文档请查看: [DEPLOYMENT.md](./DEPLOYMENT.md)

## 🔧 常用命令

```bash
# 安装依赖
npm install

# 开发模式
npm run dev

# 构建生产版本
npm run build

# 预览构建产物
npm run preview

# 代码检查
npm run lint

# 启动生产服务器
./start-production.sh

# 停止生产服务器
pkill -f production-server.js

# 查看日志
tail -f /app/work/logs/bypass/web-app-production.log
```

## 🌐 访问地址

- 开发环境: http://localhost:5173
- 生产环境: http://localhost:3000

## 📞 技术支持

如有问题，请查看:
1. [DEPLOYMENT.md](./DEPLOYMENT.md) - 详细部署文档
2. 日志文件: `/app/work/logs/bypass/web-app-production.log`
3. 浏览器控制台错误信息

## 📝 版本信息

- 版本: v7.2 双配置完全融合版
- 构建大小: 296KB (gzip后84KB)
- 最后更新: 2026-01-28
