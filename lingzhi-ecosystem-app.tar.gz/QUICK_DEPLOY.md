# 🚀 快速部署指南

## 📝 前置要求

### 必须安装的工具

1. **Node.js** (推荐18.x或更高版本)
   - 下载地址: https://nodejs.org/
   - 检查安装: `node -v`

2. **npm** (随Node.js自动安装)
   - 检查安装: `npm -v`

### 可选工具

根据选择的部署方案，可能需要以下工具：

- **Docker** - 容器化部署
  - 下载地址: https://www.docker.com/get-started

- **Nginx** - 生产环境部署 (Linux)
  - Ubuntu/Debian: `sudo apt-get install nginx`
  - CentOS/RHEL: `sudo yum install nginx`

- **Capacitor** - 移动应用打包
  - 自动安装: `npm install @capacitor/core @capacitor/cli`

- **Android Studio** - Android应用构建
  - 下载地址: https://developer.android.com/studio

- **Xcode** - iOS应用构建 (仅macOS)
  - App Store下载

---

## 🎯 一键部署

### Linux/Mac系统

```bash
# 1. 给脚本添加执行权限
chmod +x deploy.sh

# 2. 运行部署脚本
./deploy.sh
```

### Windows系统

```batch
# 双击运行
deploy.bat
```

---

## 📋 部署选项

### 选项1: 本地开发服务器

**适用场景**: 快速开发和测试

**步骤**:
1. 运行部署脚本
2. 选择 `1) 本地开发服务器`
3. 等待服务器启动
4. 访问 `http://localhost:3000`

**特点**:
- ✅ 快速启动
- ✅ 热重载
- ✅ 开发工具支持
- ❌ 仅限本地访问

---

### 选项2: Docker容器部署

**适用场景**: 容器化部署，易于迁移

**步骤**:
1. 确保Docker已安装并运行
2. 运行部署脚本
3. 选择 `2) Docker容器部署`
4. 等待镜像构建和容器启动
5. 访问 `http://localhost` 或 `http://服务器IP`

**特点**:
- ✅ 环境隔离
- ✅ 易于迁移
- ✅ 版本控制
- ✅ 快速部署

**查看日志**:
```bash
docker logs -f lingzhi-ecosystem
```

**停止容器**:
```bash
docker stop lingzhi-ecosystem
```

**重启容器**:
```bash
docker restart lingzhi-ecosystem
```

---

### 选项3: 生产环境部署 (Nginx)

**适用场景**: 正式上线，需要域名和SSL

**前置要求**:
- 拥有服务器 (VPS/云服务器)
- 拥有域名并解析到服务器
- 已安装Nginx

**步骤**:
1. 确保Nginx已安装
2. 运行部署脚本
3. 选择 `3) 生产环境部署`
4. 输入域名（例如: example.com）
5. 等待部署完成
6. 配置SSL证书

**配置SSL证书**:
```bash
# 安装certbot
sudo apt-get install -y certbot python3-certbot-nginx

# 自动配置SSL
sudo certbot --nginx -d yourdomain.com
```

**访问**:
- HTTP: `http://yourdomain.com`
- HTTPS: `https://yourdomain.com`

**特点**:
- ✅ 生产环境
- ✅ 支持SSL
- ✅ 高性能
- ✅ 自动重启

---

### 选项4: 静态文件导出

**适用场景**: 需要自行部署到其他平台

**步骤**:
1. 运行部署脚本
2. 选择 `4) 静态文件导出`
3. 等待构建完成
4. 解压 `lingzhi-ecosystem-dist.tar.gz`
5. 将文件部署到目标服务器

**解压**:
```bash
tar -xzf lingzhi-ecosystem-dist.tar.gz
```

**部署到目标服务器**:
```bash
# 复制到服务器
scp -r dist/* user@server:/var/www/html/
```

**特点**:
- ✅ 灵活部署
- ✅ 适用于任何Web服务器
- ✅ 可以部署到CDN

---

### 选项5: 移动应用打包

**适用场景**: 构建原生移动应用

**前置条件**:

**Android**:
- 安装Java JDK (8或更高版本)
- 安装Android Studio
- 配置Android SDK

**iOS**:
- macOS系统
- 安装Xcode
- Apple开发者账号

**步骤**:
1. 运行部署脚本
2. 选择 `5) 移动应用打包`
3. 选择平台 (Android/iOS)
4. 等待Capacitor同步完成
5. 使用Android Studio/Xcode构建应用

**Android构建**:
```bash
# 使用Android Studio
# 1. 打开 android/ 目录
# 2. 选择 Build > Build Bundle(s) / APK(s) > Build APK(s)
# 3. APK文件位于 android/app/build/outputs/apk/
```

**iOS构建**:
```bash
# 使用Xcode
# 1. 打开 ios/App/App.xcworkspace
# 2. 选择 Product > Archive
# 3. 分发应用
```

**特点**:
- ✅ 原生应用体验
- ✅ 应用商店分发
- ✅ 离线使用

---

### 选项6: 仅构建项目

**适用场景**: 手动构建，自定义部署

**步骤**:
1. 运行部署脚本
2. 选择 `6) 仅构建项目`
3. 等待构建完成
4. 输出位于 `dist/` 目录

**特点**:
- ✅ 快速构建
- ✅ 自定义部署流程

---

## 🔧 手动部署

### 使用Vercel (推荐新手)

1. 注册Vercel账号: https://vercel.com/
2. 连接GitHub仓库
3. 导入项目
4. 自动构建部署

### 使用Netlify

1. 注册Netlify账号: https://www.netlify.com/
2. 连接GitHub仓库
3. 配置构建设置:
   - Build command: `npm run build`
   - Publish directory: `dist`
4. 部署

### 使用GitHub Pages

1. 安装gh-pages:
   ```bash
   npm install -D gh-pages
   ```

2. 添加部署脚本到package.json:
   ```json
   "scripts": {
     "deploy": "gh-pages -d dist"
   }
   ```

3. 部署:
   ```bash
   npm run build
   npm run deploy
   ```

---

## 📊 部署对比

| 部署方案 | 难度 | 适用场景 | 性能 | 成本 |
|---------|------|---------|------|------|
| 本地开发 | ⭐ | 开发测试 | ⭐⭐ | 免费 |
| Docker | ⭐⭐ | 容器化部署 | ⭐⭐⭐ | 免费 |
| Nginx生产 | ⭐⭐⭐ | 正式上线 | ⭐⭐⭐⭐⭐ | 低 |
| Vercel/Netlify | ⭐ | 快速上线 | ⭐⭐⭐⭐ | 免费 |
| 移动应用 | ⭐⭐⭐⭐⭐ | 原生应用 | ⭐⭐⭐⭐⭐ | 中 |

---

## 🐛 故障排查

### 问题1: Node.js未安装

**解决方案**:
- 下载并安装Node.js: https://nodejs.org/
- 重新运行脚本

### 问题2: npm install失败

**解决方案**:
```bash
# 清除缓存
npm cache clean --force

# 删除node_modules
rm -rf node_modules package-lock.json

# 重新安装
npm install
```

### 问题3: 构建失败

**解决方案**:
```bash
# 清理构建缓存
rm -rf dist

# 重新构建
npm run build
```

### 问题4: Docker构建失败

**解决方案**:
```bash
# 检查Docker是否运行
docker ps

# 清理Docker缓存
docker system prune -a

# 重新构建
docker build -t lingzhi-ecosystem:latest .
```

### 问题5: Nginx配置测试失败

**解决方案**:
```bash
# 检查配置语法
sudo nginx -t

# 查看错误日志
sudo tail -f /var/log/nginx/error.log
```

---

## 📞 获取帮助

遇到问题？查看详细文档：
- 生产部署: `DEPLOYMENT.md`
- 公网部署: `PUBLIC_DEPLOYMENT.md`
- Coze集成: `COZE_INTEGRATION.md`

---

## 🎉 部署成功

恭喜！您的应用已成功部署！🚀

下一步：
- 测试所有功能
- 配置监控和分析
- 收集用户反馈
- 持续优化改进

---

**祝您部署顺利！** 💪
