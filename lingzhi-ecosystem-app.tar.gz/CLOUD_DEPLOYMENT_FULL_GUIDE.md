# 🚀 灵值生态园APP - 云平台部署全景指南

**从开发到公网访问，让用户可以像您一样使用**

---

## 📋 目录

1. [部署方案选择](#部署方案选择)
2. [准备工作](#准备工作)
3. [免费云托管部署（推荐）](#免费云托管部署推荐)
4. [生产环境部署](#生产环境部署)
5. [域名和SSL配置](#域名和ssl配置)
6. [测试验证](#测试验证)
7. [用户访问指南](#用户访问指南)
8. [维护和更新](#维护和更新)

---

## 🎯 部署方案选择

### 方案对比

| 方案 | 时间 | 难度 | 费用 | 推荐度 | 适用场景 |
|------|------|------|------|--------|---------|
| **Vercel/Netlify** | 5分钟 | ⭐ | 免费 | ⭐⭐⭐⭐⭐ | 个人项目、快速上线 |
| **阿里云/腾讯云** | 30分钟 | ⭐⭐⭐ | ¥80-200/年 | ⭐⭐⭐⭐⭐ | 企业级应用 |
| **自己的服务器** | 1小时 | ⭐⭐⭐⭐ | ¥200-500/年 | ⭐⭐⭐ | 完全控制 |

### 推荐：Vercel免费云托管（最适合您）

**理由**：
- ✅ 完全免费
- ✅ 5分钟即可完成
- ✅ 自动HTTPS
- ✅ 全球CDN加速
- ✅ 自动更新部署
- ✅ 适合展示给用户使用

---

## 📦 准备工作

### 1. GitHub账号（必需）

**如果没有GitHub账号**：
1. 访问 https://github.com/
2. 点击 "Sign up"
3. 注册免费账号
4. 验证邮箱

### 2. 项目代码（必需）

**检查项目完整性**：
```bash
cd /workspace/projects/web-app

# 检查关键文件
ls -la package.json
ls -la src/main.tsx
ls -la src/App.tsx

# 确认可以构建
npm run build
```

### 3. Git工具（推荐）

**检查Git是否安装**：
```bash
git --version
```

**如果没有安装**：
- Windows: 下载 https://git-scm.com/download/win
- Mac: 系统自带或使用 `brew install git`
- Linux: `sudo apt-get install git`

---

## 🌟 免费云托管部署（推荐）

### 方案1：使用Vercel（推荐新手）

#### 步骤1：创建GitHub仓库

**1.1 在GitHub创建仓库**：
1. 登录 https://github.com/
2. 点击右上角 "+" > "New repository"
3. 填写信息：
   - Repository name: `lingzhi-ecosystem-app`
   - Description: 灵值生态园智能体应用
   - 选择 Public（公开）或 Private（私有）
4. 点击 "Create repository"

**1.2 初始化Git仓库**：
```bash
cd /workspace/projects/web-app

# 初始化Git仓库
git init

# 添加所有文件
git add .

# 提交
git commit -m "Initial commit: 灵值生态园APP v7.3"

# 添加远程仓库（替换为你的仓库地址）
git remote add origin https://github.com/yourusername/lingzhi-ecosystem-app.git

# 推送到GitHub
git branch -M main
git push -u origin main
```

**1.3 验证推送成功**：
- 访问你的GitHub仓库
- 确认所有文件都已上传

---

#### 步骤2：部署到Vercel

**2.1 注册Vercel**：
1. 访问 https://vercel.com/
2. 点击 "Sign Up"
3. 选择 "Continue with GitHub"
4. 授权Vercel访问你的GitHub
5. 免费注册完成

**2.2 导入项目**：
1. 登录Vercel后，点击 "Add New..."
2. 选择 "Project"
3. 找到 `lingzhi-ecosystem-app` 仓库
4. 点击 "Import"

**2.3 配置项目**：

**Framework Preset**: 选择 `Vite`

**Project Settings**:
```
Name: lingzhi-ecosystem-app
Framework Preset: Vite
Root Directory: ./
```

**Build and Output Settings**:
```
Build Command: npm run build
Output Directory: dist
Install Command: npm install
```

**Environment Variables**（可选）：
如果需要配置环境变量，点击"Environment Variables"添加：
```
VITE_API_BASE_URL=https://your-api.com
```

**2.4 部署**：
1. 点击 "Deploy" 按钮
2. 等待1-2分钟（首次部署可能需要5分钟）
3. 看到 "Congratulations!" 表示部署成功

---

#### 步骤3：获取访问地址

**Vercel自动生成的域名**：
```
https://lingzhi-ecosystem-app-xxxx.vercel.app
```

**如何查看**：
1. 在Vercel项目页面
2. 点击 "Domains" 标签
3. 查看默认域名
4. 点击 "Visit" 访问应用

**示例**：
```
https://lingzhi-ecosystem-app-a1b2c3d4.vercel.app
```

---

#### 步骤4：测试应用

**4.1 访问应用**：
- 点击Vercel提供的域名
- 或直接访问: `https://lingzhi-ecosystem-app-xxxx.vercel.app`

**4.2 测试登录**：
- 点击"登录"
- 输入任意账号密码（test/test123）
- 确认登录成功

**4.3 测试功能**：
- 智能对话功能
- 经济模型计算
- 用户旅程查看
- 个人中心

**4.4 在手机上测试**：
- 用手机浏览器访问Vercel域名
- 测试移动端体验

---

### 方案2：使用Netlify（备选）

**步骤**：

1. **注册Netlify**：
   - 访问 https://www.netlify.com/
   - 使用GitHub登录
   - 免费注册

2. **连接GitHub**：
   - 点击 "Add new site"
   - 选择 "Import an existing project"
   - 连接GitHub

3. **配置构建**：
   ```
   Build command: npm run build
   Publish directory: dist
   ```

4. **部署**：
   - 点击 "Deploy site"
   - 等待部署完成

5. **访问应用**：
   ```
   https://lingzhi-ecosystem-app.netlify.app
   ```

---

## 🏢 生产环境部署（企业级）

### 方案1：阿里云部署

#### 前置准备

**1. 购买服务器**：
- 访问 https://www.aliyun.com/
- 购买云服务器ECS
- 配置推荐：
  - 规格: 2核4GB
  - 系统: Ubuntu 20.04 LTS
  - 带宽: 3Mbps
  - 费用: 约 ¥100/年

**2. 购买域名**：
- 访问 https://wanwang.aliyun.com/
- 购买域名（.com 或 .cn）
- 费用: 约 ¥50-100/年

**3. 解析域名**：
- 登录阿里云域名管理
- 添加A记录：
  - 主机记录: @
  - 记录值: 服务器公网IP
- 等待DNS生效（5-10分钟）

---

#### 部署步骤

**步骤1：连接服务器**：
```bash
ssh root@your-server-ip
```

**步骤2：安装必要软件**：
```bash
# 更新软件包
apt-get update

# 安装Nginx
apt-get install -y nginx

# 安装Node.js
curl -fsSL https://deb.nodesource.com/setup_18.x | bash -
apt-get install -y nodejs

# 安装Git
apt-get install -y git

# 验证安装
node -v
npm -v
nginx -v
```

**步骤3：克隆项目**：
```bash
# 克隆项目（替换为你的仓库地址）
git clone https://github.com/yourusername/lingzhi-ecosystem-app.git

# 进入项目目录
cd lingzhi-ecosystem-app/web-app
```

**步骤4：构建项目**：
```bash
# 安装依赖
npm install

# 构建项目
npm run build
```

**步骤5：部署到Nginx**：
```bash
# 创建网站目录
mkdir -p /var/www/lingzhi-ecosystem

# 复制构建文件
cp -r dist/* /var/www/lingzhi-ecosystem/

# 设置权限
chown -R www-data:www-data /var/www/lingzhi-ecosystem
chmod -R 755 /var/www/lingzhi-ecosystem
```

**步骤6：配置Nginx**：
```bash
# 创建Nginx配置文件
nano /etc/nginx/sites-available/lingzhi-ecosystem
```

**添加以下配置**：
```nginx
server {
    listen 80;
    server_name yourdomain.com www.yourdomain.com;

    root /var/www/lingzhi-ecosystem;
    index index.html;

    location / {
        try_files $uri $uri/ /index.html;
    }

    # Gzip压缩
    gzip on;
    gzip_types text/plain text/css application/json application/javascript text/xml application/xml application/xml+rss text/javascript;

    # 缓存静态资源
    location ~* \.(js|css|png|jpg|jpeg|gif|ico|svg|woff|woff2)$ {
        expires 1y;
        add_header Cache-Control "public, immutable";
    }
}
```

**保存并退出**（Ctrl+X, Y, Enter）

**启用配置**：
```bash
# 创建符号链接
ln -s /etc/nginx/sites-available/lingzhi-ecosystem /etc/nginx/sites-enabled/

# 测试配置
nginx -t

# 重启Nginx
systemctl restart nginx

# 设置开机自启
systemctl enable nginx
```

**步骤7：配置SSL证书**：
```bash
# 安装Certbot
apt-get install -y certbot python3-certbot-nginx

# 自动配置SSL
certbot --nginx -d yourdomain.com -d www.yourdomain.com

# 按提示操作
# 1. 输入邮箱
# 2. 同意条款
# 3. 选择是否重定向HTTP到HTTPS（推荐选择Yes）
```

---

#### 步骤8：验证部署

**访问应用**：
- HTTP: http://yourdomain.com
- HTTPS: https://yourdomain.com（推荐）

**测试功能**：
- 页面加载正常
- 登录功能正常
- 所有路由可访问

---

### 方案2：腾讯云部署（类似）

**步骤与阿里云类似**：
1. 购买腾讯云CVM
2. 购买域名（腾讯云DNSPod）
3. 解析域名
4. 连接服务器
5. 安装Nginx和Node.js
6. 部署应用
7. 配置SSL

---

## 🔐 域名和SSL配置

### 配置自定义域名（Vercel）

**步骤1：购买域名**：
- 阿里云万网: https://wanwang.aliyun.com/
- 腾讯云DNSPod: https://dnspod.cloud.tencent.com/
- GoDaddy: https://www.godaddy.com/

**步骤2：添加DNS记录**：
在域名管理面板添加CNAME记录：
```
类型: CNAME
主机记录: www（或其他子域名）
记录值: cname.vercel-dns.com
```

**步骤3：在Vercel添加域名**：
1. 进入Vercel项目设置
2. 点击 "Domains"
3. 输入你的域名
4. 点击 "Add"

**步骤4：等待DNS生效**：
- 通常需要5-10分钟
- 最多24小时

**步骤5：自动SSL**：
- Vercel会自动配置SSL证书
- 等待证书颁发（1-2分钟）

---

## ✅ 测试验证

### 功能测试清单

**基础功能**：
- [ ] 首页正常加载
- [ ] 登录功能正常
- [ ] 注册功能正常
- [ ] 登录后跳转正常

**核心功能**：
- [ ] 智能对话功能
- [ ] 经济模型计算
- [ ] 用户旅程查看
- [ ] 合伙人管理
- [ ] 个人中心

**PWA功能**：
- [ ] 可以添加到主屏幕
- [ ] 可以离线访问
- [ ] 应用图标显示正常

**性能测试**：
- [ ] 首屏加载时间 < 3秒
- [ ] 页面切换流畅
- [ ] 无明显卡顿

**兼容性测试**：
- [ ] Chrome浏览器
- [ ] Firefox浏览器
- [ ] Safari浏览器
- [ ] Edge浏览器
- [ ] 手机浏览器
- [ ] 平板浏览器

---

## 👥 用户访问指南

### 给用户的访问方式

**方式1：直接访问域名**
```
https://yourdomain.com
```

**方式2：通过二维码**
```
1. 生成二维码
2. 用户扫码访问
3. 保存为书签
```

**方式3：通过应用商店**
```
1. 打包为移动应用
2. 上架到应用商店
3. 用户下载安装
```

---

### 用户登录指导

**给用户的登录说明**：

```
🌐 灵值生态园APP - 访问指南

📱 访问地址：
https://yourdomain.com

🔐 登录方式：
1. 点击"登录"按钮
2. 输入任意用户名和密码
3. 点击"登录"即可

📝 示例账号：
用户名: test
密码: test123

💡 提示：
- 可以使用任意账号密码登录
- 首次登录自动创建账户
- 支持游客模式体验

📱 移动端：
1. 在手机浏览器打开网址
2. 点击"添加到主屏幕"
3. 像原生应用一样使用
```

---

## 🔄 维护和更新

### 更新应用

**方式1：Git推送自动部署（推荐）**：
```bash
# 修改代码后
git add .
git commit -m "Update: 新功能"
git push

# Vercel/Netlify会自动检测并重新部署
```

**方式2：手动触发部署**：
- Vercel: 点击 "Redeploy"
- Netlify: 点击 "Deploys" > "Trigger deploy"

### 监控应用

**Vercel Analytics**：
1. 进入项目设置
2. 启用Analytics
3. 查看访问统计

**监控指标**：
- 访问量
- 页面加载时间
- 错误率
- 用户来源

### 备份

**代码备份**：
- GitHub自动备份
- 定期推送更新

**数据备份**：
- 用户数据存储在localStorage
- 建议添加后端数据库

---

## 📊 成本对比

| 方案 | 服务器 | 域名 | SSL | 年度费用 |
|------|--------|------|-----|----------|
| Vercel | 免费 | 可选 | 免费 | ¥0-100 |
| Netlify | 免费 | 可选 | 免费 | ¥0-100 |
| 阿里云 | ¥50-100 | ¥50-100 | 免费 | ¥100-200 |
| 腾讯云 | ¥50-100 | ¥30-100 | 免费 | ¥80-200 |

---

## 🎯 推荐部署路线

### 新手路线（推荐）

**第1步：使用Vercel快速部署（5分钟）**
1. 推送代码到GitHub
2. 连接Vercel
3. 自动部署
4. 立即可用

**第2步：配置自定义域名（可选，2分钟）**
1. 购买域名
2. 配置DNS
3. 在Vercel添加域名
4. 自动SSL

**第3步：分享给用户（1分钟）**
1. 发送域名链接
2. 创建二维码
3. 用户访问使用

---

### 专业路线

**第1步：购买服务器（10分钟）**
- 阿里云或腾讯云
- 配置服务器环境

**第2步：部署应用（20分钟）**
- 安装Nginx
- 部署项目
- 配置SSL

**第3步：优化配置（10分钟）**
- CDN加速
- 监控告警
- 自动备份

---

## 🎉 完成检查清单

### 部署完成确认

- [ ] 应用成功部署
- [ ] 可以通过域名访问
- [ ] HTTPS证书已配置
- [ ] 所有功能正常
- [ ] 移动端访问正常
- [ ] PWA功能正常

### 用户可用性确认

- [ ] 用户可以访问
- [ ] 用户可以登录
- [ ] 用户可以使用所有功能
- [ ] 移动端体验良好
- [ ] 加载速度可接受

---

## 📞 技术支持

### 遇到问题？

1. **查看文档**：
   - Vercel文档: https://vercel.com/docs
   - Netlify文档: https://docs.netlify.com/

2. **查看日志**：
   - Vercel: 项目 > Deployments > 日志
   - Netlify: Deploys > 日志

3. **获取帮助**：
   - GitHub Issues
   - 官方论坛
   - 技术支持邮箱

---

## 🚀 开始部署！

**现在就开始，5分钟后用户就能使用！**

### 快速开始（Vercel）

```bash
# 1. 推送到GitHub
git init
git add .
git commit -m "Initial commit"
git remote add origin https://github.com/yourusername/repo.git
git push -u origin main

# 2. 访问Vercel
# https://vercel.com/

# 3. 导入项目并部署
# 5分钟完成！
```

---

**祝您部署顺利！** 🎉

现在用户就可以像您一样使用这个应用了！
